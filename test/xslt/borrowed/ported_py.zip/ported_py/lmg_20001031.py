########################################################################
# test/xslt/lmg_20001031.py
# Lars Marius Garshol <larsga@garshol.priv.no> reports bugs

import os
import cStringIO
import unittest

from amara.lib import treecompare
from amara.test import test_main
from amara.test.xslt import xslt_test, filesource, stringsource, XsltError

class test_xslt_bugtest_1_lmg_20001031(xslt_test):
    error_code = XsltError.STYLESHEET_REQUESTED_TERMINATION
    source = stringsource("<xbel/>")
    transform = stringsource("""<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:foo="http://foo.org/xslt/extensions"
                extension-element-prefixes="foo"
                version="1.0">

  <xsl:template match = "/">
    <foo:bar really-useful-attribute = "bing">
      [...proceed to use the foo:bar instruction for something
    useful...]

      <xsl:fallback>
        <xsl:message terminate="yes">
        Sorry, support for the foo:bar element required to run this
        stylesheet. Try using the XSLT processor from foo.org instead!
        </xsl:message>
      </xsl:fallback>
    </foo:bar>
  </xsl:template>

</xsl:stylesheet>""")
    parameters = {}
    expected = """"""

if __name__ == '__main__':
    test_main()
