########################################################################
# test/xslt/evdv_20030203-1.py
#http://sourceforge.net/tracker/index.php?func=detail&aid=679360&group_id=39954&atid=428292

import os
import cStringIO
import unittest

from amara.lib import treecompare
from amara.test import test_main
from amara.test.xslt import xslt_test, filesource, stringsource

class test_xslt_copy_namespace_evdv_20030203_1(xslt_test):
    source = stringsource("""\
<?xml version="1.0" encoding="UTF-8"?>
<xpath
xmlns:foo="http://examplotron.com/namespaces/example"
expr="/foo:bar"/>
""")
    transform = stringsource("""\
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="xpath">
    <xpath>
      <xsl:copy-of select="namespace::* "/>
      <xsl:value-of select="@expr"/>
    </xpath>
  </xsl:template>

</xsl:stylesheet>
""")
    parameters = {}
    expected = """<?xml version="1.0" encoding="UTF-8"?>
<xpath xmlns:foo="http://examplotron.com/namespaces/example">/foo:bar</xpath>"""

if __name__ == '__main__':
    test_main()
